// Kristofer Mann
// PAP6 - 1802
// MainActivity.java
package com.example.klae.mannkristofer_pap6project;

import android.Manifest;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.location.Location;
import android.location.LocationListener;
import android.location.LocationManager;
import android.net.Uri;
import android.support.annotation.NonNull;
import android.support.v4.app.ActivityCompat;
import android.support.v4.app.FragmentActivity;
import android.support.v4.content.ContextCompat;
import android.os.Bundle;
import android.app.AlertDialog;
import android.view.LayoutInflater;
import android.view.View;
import android.widget.Button;
import android.widget.ImageButton;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import com.example.klae.mannkristofer_pap6project.data.DataHandler;
import com.example.klae.mannkristofer_pap6project.network.DataTask;
import com.example.klae.mannkristofer_pap6project.network.DetailsDataTask;
import com.example.klae.mannkristofer_pap6project.network.NetworkUtilities;
import com.example.klae.mannkristofer_pap6project.objects.Details;
import com.example.klae.mannkristofer_pap6project.objects.Place;
import com.google.android.gms.maps.CameraUpdate;
import com.google.android.gms.maps.CameraUpdateFactory;
import com.google.android.gms.maps.GoogleMap;
import com.google.android.gms.maps.OnMapReadyCallback;
import com.google.android.gms.maps.SupportMapFragment;
import com.google.android.gms.maps.model.LatLng;
import com.google.android.gms.maps.model.Marker;
import com.google.android.gms.maps.model.MarkerOptions;
import com.squareup.picasso.Picasso;

import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.util.ArrayList;
import java.util.Objects;
import java.util.Random;

public class MainActivity extends FragmentActivity implements LocationListener, OnMapReadyCallback, GoogleMap.InfoWindowAdapter, GoogleMap.OnInfoWindowClickListener {

    private static final int REQUEST_LOCATION_PERMISSIONS = 0x01002;
    private LocationManager mLocationManager;
    private boolean mRequestUpdate = false;
    private GoogleMap mMap;
    private ArrayList<Place> mPlaces;
    private ArrayList<Place> mPlaceOptions;
    private ArrayList<Place> mFavoritePlaces;
    private ArrayList<Place> mDiscardedPlaces;
    private Details mDetails;
    private LatLng mUserLocation;
    private boolean mFavoritesSelected = false;
    public static final String EXTRA_LOCATION = "EXTRA_LOCATION";
    public static final String ARGS_BUNDLE = "ARGS_BUNDLE";

    // This sets the view to maps activity to display the google map
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_maps);
        SupportMapFragment mapFragment = (SupportMapFragment) getSupportFragmentManager()
                .findFragmentById(R.id.map);

        mapFragment.getMapAsync(this);

        // This gets the system location service and sets it the the manager
        // Then all of the arrayList are set to new arrayList to ensure they are active from the beginning
        mLocationManager = (LocationManager)getSystemService(Context.LOCATION_SERVICE);
        mPlaces = new ArrayList<>();
        mPlaceOptions = new ArrayList<>();
        mFavoritePlaces = new ArrayList<>();
        mDiscardedPlaces = new ArrayList<>();

        // This calls the getRandomPlace method to provide a random location to the map
        // It provides the method with an arrayList based upon the user selecting the favorites button or not
        Button feastButton = (Button)findViewById(R.id.feast_button);
        feastButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if(mFavoritesSelected){
                    getRandomPlace(mFavoritePlaces);
                }else {
                    getRandomPlace(mPlaceOptions);
                }
            }
        });

        // This is where the user performs the action to display their favorite locations
        // If it is already selected, then the map is cleared, the camera zooms in and the image button changes to a star
        final ImageButton settingsButton = (ImageButton) findViewById(R.id.settings_button);
        final ImageButton favoritesButton = (ImageButton) findViewById(R.id.favorites_button);
        favoritesButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if(mFavoritesSelected){
                    mFavoritesSelected = false;
                    mMap.clear();
                    CameraUpdate cameraUpdate = CameraUpdateFactory.newLatLngZoom(mUserLocation,13);
                    mMap.animateCamera(cameraUpdate,1000,null);
                    favoritesButton.setImageResource(R.drawable.ic_favorite);
                    settingsButton.setVisibility(View.VISIBLE);
                }else {
                    // If it is not selected, it changes the bool to identify that and changes the image button to cancel
                    // It clears the map and loops through all of the favorite locations
                    // Each location is added to the map as a marker and the marker sets its tag to the place as a reference later
                    // The camera zooms out to be able to display all of the locations
                    // If there not any favorites, the user is informed of that with a toast
                    if(mFavoritePlaces != null && !mFavoritePlaces.isEmpty()){
                        mFavoritesSelected = true;
                        favoritesButton.setImageResource(R.drawable.ic_cancel);
                        settingsButton.setVisibility(View.GONE);
                        mMap.clear();
                        for(int i=0;i<mFavoritePlaces.size();i++){
                            Place place = mFavoritePlaces.get(i);
                            LatLng loc = new LatLng(Double.parseDouble(place.getLat()),Double.parseDouble(place.getLng()));
                            mMap.addMarker(new MarkerOptions().position(loc).title(place.getName())).setTag(place);
                        }
                        CameraUpdate cameraUpdate = CameraUpdateFactory.newLatLngZoom(mUserLocation,12);
                        mMap.animateCamera(cameraUpdate,1000,null);
                    }else{
                        mFavoritesSelected = false;
                        Toast.makeText(MainActivity.this,"No favorites saved!",Toast.LENGTH_SHORT).show();
                    }
                }
            }
        });

        // This takes the user to the settings screen
        // It clears the map because the shown marker is no longer needed
        // Then it puts the user's location in the intent for the settings to use
        settingsButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                mMap.clear();
                Intent intent = new Intent(MainActivity.this,SettingsActivity.class);
                Bundle args = new Bundle();
                args.putParcelable(ARGS_BUNDLE,mUserLocation);
                intent.putExtra(EXTRA_LOCATION,args);
                MainActivity.this.startActivityForResult(intent,1);
            }
        });
    }

    // This is where the app updates it data after the user leaves the settings screen
    // Favorites and discarded places are reloaded into their arrayLists because the data could have changed
    // It uses the loadPlaces method because the dataHandler was not created at the time
    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        mFavoritePlaces = loadPlaces("favorite");
        mDiscardedPlaces = loadPlaces("discard");

        // This creates a new dataHandler to retrieve the current location of the user because it could have changed in settings
        // The user has the capability of saving several location and switching between them, so this must be updated
        // The map is updated with the location the user has chosen and the data is loaded
        DataHandler dataHandler = new DataHandler();
        Place currentLocation = dataHandler.loadLocation(this,"current");
        if(currentLocation != null && !Objects.equals(currentLocation.getLat(), String.valueOf(mUserLocation.latitude))){
            mUserLocation = new LatLng(Double.parseDouble(currentLocation.getLat()),Double.parseDouble(currentLocation.getLng()));
            CameraUpdate cameraUpdate = CameraUpdateFactory.newLatLngZoom(mUserLocation,13);
            mMap.animateCamera(cameraUpdate,1000,null);
            loadAppData();
        }

        // This checks to see if an update has happened to the map based upon the filter
        // If so, it loads the new data and saves it with the method
        if(dataHandler.loadUpdateBool(this,"update")){
            getChosenPlace(dataHandler.loadPlaces(this,"filterplaces"));
            dataHandler.saveUpdateBool(this,false,"update");
        }
    }

    // This is where the random places are generated
    // It makes sure that the places are not empty so that it does not crash in case there are not any places
    // The map is cleared and a random int is chosen based upon the size of the arrayList
    // Then it retrieves a place from the arrayList based upon that int
    private void getRandomPlace(ArrayList<Place> places){
        if(!places.isEmpty()){
            mMap.clear();
            int r = new Random().nextInt(places.size());
            Place place = places.get(r);

            // A new LatLng is created to retrieve the location of the marker
            // The marker is created with its tag set to the place to be used as a reference in the info window click
            // The map zooms into to the location just in case it was zoomed out from being in the favorites screen
            LatLng loc = new LatLng(Double.parseDouble(place.getLat()),Double.parseDouble(place.getLng()));
            mMap.addMarker(new MarkerOptions().position(loc).title(place.getName())).setTag(place);
            CameraUpdate cameraUpdate = CameraUpdateFactory.newLatLngZoom(loc,13);
            mMap.animateCamera(cameraUpdate,1000,null);

            // This begins the process of retrieving the details data as soon as the selection has been made
            // This is so that the data can be provided before the user taps to see the details screen
            // It is meant to keep the user from waiting
            if(!mFavoritesSelected){
                mPlaceOptions.remove(r);
                NetworkUtilities utilities = new NetworkUtilities();
                if(utilities.isConnected(MainActivity.this)){
                    DetailsDataTask detailsDataTask = new DetailsDataTask(MainActivity.this,place.getId());
                    detailsDataTask.execute();
                }

                // This provides the arrayList with the saved data when it runs out of places
                // Its meant to keep the user from running out of locations
                if(mPlaceOptions.size() == 0){
                    for(Place p: mPlaces){
                        mPlaceOptions.add(p);
                    }
                }
            }
        }
    }

    // This is called in the DataTask and ActivityResults to provide all of the data
    // It automatically saves the places based upon the user's location longitude
    // It is saved by the longitude because it is unique
    // The latitude is used to reference the location while the longitude references the places around that location
    // It is meant to load previously saved places to prevent from having to access the API again
    // It checks for discarded places, clears the place options, and adds the backup places to the options
    public void getChosenPlace(ArrayList<Place> places){
        mPlaces = places;
        savePlaces(places,String.valueOf(mUserLocation.longitude));
        discardLocations();
        mPlaceOptions.clear();
        for(Place p: mPlaces){
            mPlaceOptions.add(p);
        }
    }

    // This receives the details data from the DetailsDataTask and sets it to the variable
    public void getDetails(Details details){
        mDetails = details;
    }

    // This is meant to check connectivity and then provide the DataTask with the context and user location
    // The dataTask is executed to retrieve locations
    private void getPlaces(){
        NetworkUtilities utilities = new NetworkUtilities();
        if(utilities.isConnected(MainActivity.this)){
            String latLng = String.valueOf(mUserLocation.latitude) + "," + String.valueOf(mUserLocation.longitude);
            DataTask dataTask = new DataTask(MainActivity.this,latLng);
            dataTask.execute();
        }
    }

    // This sets the map, infoWindowAdapter, and the infoWindowClickListener
    // It checks to see if it has permission to access the user's location and requests one
    // It either shows the user's current location or the center of the US
    @Override
    public void onMapReady(GoogleMap googleMap) {
        mMap = googleMap;
        mMap.setInfoWindowAdapter(this);
        mMap.setOnInfoWindowClickListener(this);

        if(ContextCompat.checkSelfPermission(this, Manifest.permission.ACCESS_FINE_LOCATION)
                == PackageManager.PERMISSION_GRANTED){
            showUserLocation();
        }else {
            LatLng usa = new LatLng(39.8283, -98.5795);
            mMap.moveCamera(CameraUpdateFactory.newLatLng(usa));
            ActivityCompat.requestPermissions(this,
                    new String[]{ Manifest.permission.ACCESS_FINE_LOCATION},REQUEST_LOCATION_PERMISSIONS);
        }

    }

    // This loads saved discarded locations if there are any and creates a new arrayList if there is not
    // It loops through all of the discarded places and backup places arrayList to see if any ids match
    // If they do, then it retrieves the index and removes it from the backup places
    private void discardLocations(){
        mDiscardedPlaces = loadPlaces("discard");
        if(mDiscardedPlaces != null){
            int index = 100000;
            for(Place discard: mDiscardedPlaces){
                for(int i=0;i<mPlaces.size();i++){
                    if(Objects.equals(discard.getId(), mPlaces.get(i).getId())){
                        index = i;
                    }
                }
                if(index != 100000){
                    mPlaces.remove(index);
                    index = 100000;
                }
            }
        }else {
            mDiscardedPlaces = new ArrayList<>();
        }
    }

    // This checks to see if permission was granted to see th user's location or request it
    // It is meant to update the map to the user's location
    private void showUserLocation(){
        if(ContextCompat.checkSelfPermission(this, Manifest.permission.ACCESS_FINE_LOCATION)
                == PackageManager.PERMISSION_GRANTED){
            Location mLocation = mLocationManager.getLastKnownLocation(LocationManager.NETWORK_PROVIDER);

            // This creates a new LatLng based upon the location and sets it to the user's
            // The camera moves to the location and zooms in
            // Then the data is loaded with the method
            if(mLocation != null){
                mUserLocation = new LatLng(mLocation.getLatitude(), mLocation.getLongitude());
                CameraUpdate cameraUpdate = CameraUpdateFactory.newLatLngZoom(mUserLocation,13);
                mMap.animateCamera(cameraUpdate,1000,null);
                loadAppData();

                // This sets the user's location as a string to be stored in the dataHandler as the current location
                // It is referenced later in the settings screens
                Place currentLocation = new Place(String.valueOf(mUserLocation.latitude),String.valueOf(mUserLocation.longitude),
                        "current location",String.valueOf(mUserLocation.latitude),false);
                DataHandler dataHandler = new DataHandler();
                dataHandler.saveLocation(this,currentLocation,"current");
            }else {
                mLocationManager.requestLocationUpdates(LocationManager.NETWORK_PROVIDER,2000,10.0f,this);
                mRequestUpdate = true;
            }
        }
    }

    // This loads all of the data for the app in three different ways based upon saved locations
    // The saved location is loaded by its latitude because it will be saved this way if it does not exist
    // If it is null, then getPlaces is called to load the data and a new arrayList is set
    // Then, it adds the location to the arrayList and saves it by its latitude
    private void loadAppData(){
        ArrayList<Place> mSavedLocations = loadPlaces(String.valueOf(mUserLocation.latitude));
        if(mSavedLocations == null){
            getPlaces();
            mSavedLocations = new ArrayList<>();
            mSavedLocations.add(new Place(String.valueOf(mUserLocation.latitude),String.valueOf(mUserLocation.longitude),"name",String.valueOf(mUserLocation.latitude), false));
            savePlaces(mSavedLocations,String.valueOf(mUserLocation.latitude));
        }else {

            // If there is saved locations in the arrayList, then it loops through it to see if any ids match
            String locationId = null;
            for(Place p: mSavedLocations){
                if(Objects.equals(p.getId(), String.valueOf(mUserLocation.latitude))){
                    locationId = p.getId();
                }
            }

            // If none of them match, then its a new location and it must be saved and the data gets retrieved
            // It calls getPlaces, adds the new location to the arrayList, and then saves the arrayList
            // This is so the location can be reference in the future
            if(locationId == null){
                getPlaces();
                mSavedLocations.add(0,new Place(String.valueOf(mUserLocation.latitude),String.valueOf(mUserLocation.longitude),"name",String.valueOf(mUserLocation.latitude), false));
                savePlaces(mSavedLocations,String.valueOf(mUserLocation.latitude));
            }else {

                // If an id does match, then it loads all of the location's restaurants by it longitude
                // It filters out the discarded locations, clears the options, and adds all of the backups to the options
                mPlaces = loadPlaces(String.valueOf(mUserLocation.longitude));
                discardLocations();
                mPlaceOptions.clear();
                for(Place place: mPlaces){
                    mPlaceOptions.add(place);
                }

                // Then it loads all of the favorites if there are any or creates a new arrayList
                // Then loops through each of the options to set certain places as favorites for the info window
                mFavoritePlaces = loadPlaces("favorite");
                if(mFavoritePlaces == null){
                    mFavoritePlaces = new ArrayList<>();
                }else {
                    for(Place place: mPlaceOptions){
                        for(Place p: mFavoritePlaces){
                            if(Objects.equals(place.getId(), p.getId())){
                                p.setFavorite(true);
                            }
                        }
                    }
                }
            }
        }
    }

    // Shows the user's location when the location is changed
    @Override
    public void onLocationChanged(Location location) {
        if(mRequestUpdate){
            mRequestUpdate = false;
            mLocationManager.removeUpdates(this);
            showUserLocation();
        }
    }

    // Shows the user's location when the permission is granted
    @Override
    public void onRequestPermissionsResult(int requestCode, @NonNull String[] permissions, @NonNull int[] grantResults) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults);
        if(grantResults.length > 0 && grantResults[0] == PackageManager.PERMISSION_GRANTED){
            showUserLocation();
        }
    }

    // empty
    @Override
    public void onStatusChanged(String provider, int status, Bundle extras) {

    }

    // empty
    @Override
    public void onProviderEnabled(String provider) {

    }

    // empty
    @Override
    public void onProviderDisabled(String provider) {

    }

    // null
    @Override
    public View getInfoWindow(Marker marker) {
        return null;
    }

    // Provides larger view for the user to be able to tap because the other was too small
    @Override
    public View getInfoContents(Marker marker) {

        View view = LayoutInflater.from(MainActivity.this).inflate(R.layout.info_window,null);
        ((TextView)view.findViewById(R.id.name_textView)).setText(marker.getTitle());

        return view;
    }

    // This displays the details inside of an alert dialog
    // It provides the user with an opportunity to visit the website, discard a location, or save to favorites
    @Override
    public void onInfoWindowClick(final Marker marker) {

        // Sets a place by the marker tag and sets the strings for the photo url key
        final Place place = (Place) marker.getTag();
        String photoURL = "https://maps.googleapis.com/maps/api/place/photo?maxwidth=400&photoreference=";
        String key = "&key=AIzaSyC_NdBwpYCegNicZGxECXmJN1p9wL7vCwc";

        // An alertDialog is created and a custom view is provided to is
        final AlertDialog.Builder alertDialog = new AlertDialog.Builder(MainActivity.this);
        LayoutInflater layoutInflater = getLayoutInflater();
        final View view = layoutInflater.inflate(R.layout.details_view,null);
        alertDialog.setView(view);
        alertDialog.setCancelable(true);

        // The textView is set by its id and provided the title
        TextView name = (TextView)view.findViewById(R.id.name_textView);
        name.setText(marker.getTitle());

        // Each of the UI elements are set by their associated ids
        final ImageView photoImageView = (ImageView)view.findViewById(R.id.photo_imageView);
        final TextView addressTextView = (TextView)view.findViewById(R.id.address_textView);
        final TextView numberTextView = (TextView)view.findViewById(R.id.number_textView);
        final Button websiteButton = (Button)view.findViewById(R.id.website_button);
        final TextView ratingTextView = (TextView)view.findViewById(R.id.rating_textView);
        final TextView priceLebelTextView = (TextView)view.findViewById(R.id.priceLevel_textView);
        final TextView weekdayTextView = (TextView)view.findViewById(R.id.weekday_textView);
        final ImageButton addFavoriteButton = (ImageButton)view.findViewById(R.id.addFavorite_button);
        final ImageButton discardButton = (ImageButton)view.findViewById(R.id.discard_button);

        // This sets the UI elements with their associated details data
        // If it is a favorite place, then it sets them by its details already save
        // Otherwise, the elements are set by the mDetails object that was created when the user chose a place
        //noinspection ConstantConditions
        if(place.isFavorite()){
            addFavoriteButton.setImageResource(R.drawable.ic_remove_circle_outline);
            final Details details = place.getDetails();
            Picasso.with(MainActivity.this).load(photoURL + details.getPhotoURL() + key).fit().centerCrop().into(photoImageView);
            addressTextView.setText("Address: "+details.getAddress());
            numberTextView.setText("Number: "+details.getNumber());
            websiteButton.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    Intent intent = new Intent(Intent.ACTION_VIEW, Uri.parse(details.getWebsite()));
                    startActivity(intent);
                }
            });
            ratingTextView.setText("Rating: "+details.getRating());
            priceLebelTextView.setText("Price Level: "+details.getPriceLevel());
            weekdayTextView.setText(details.getHours());
        }else {
            addFavoriteButton.setImageResource(R.drawable.ic_star_border);
            if(mDetails != null){
                Picasso.with(MainActivity.this).load(photoURL + mDetails.getPhotoURL() + key).fit().centerCrop().into(photoImageView);
                addressTextView.setText("Address: "+mDetails.getAddress());
                numberTextView.setText("Number: "+mDetails.getNumber());
                websiteButton.setOnClickListener(new View.OnClickListener() {
                    @Override
                    public void onClick(View v) {
                        Intent intent = new Intent(Intent.ACTION_VIEW, Uri.parse(mDetails.getWebsite()));
                        startActivity(intent);
                    }
                });
                ratingTextView.setText("Rating: "+mDetails.getRating());
                priceLebelTextView.setText("Price Level: "+mDetails.getPriceLevel());
                weekdayTextView.setText(mDetails.getHours());
            }
        }

        // This is the button that adds or removes a location from the favorites
        // If the place is a favorite, the index within the array is found and th item is removed
        // The marker is also removed from the map while the place sets its favorite bool to false
        // Favorites arrayList is then saved and the backup arrayList is changed
        // The button image is changed to the star border and the discardButton is shown
        addFavoriteButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if(place.isFavorite()){
                    int index = 100000;
                    for(int i=0; i<mFavoritePlaces.size();i++){
                        if(Objects.equals(mFavoritePlaces.get(i).getId(), place.getId())){
                            index = i;
                        }
                    }
                    if(index != 100000){
                        mFavoritePlaces.remove(index);
                        marker.remove();
                        place.setFavorite(false);
                        savePlaces(mFavoritePlaces,"favorite");
                        updateTempLocations(place);
                        addFavoriteButton.setImageResource(R.drawable.ic_star_border);
                        discardButton.setVisibility(View.VISIBLE);
                        Toast.makeText(MainActivity.this,"Removed",Toast.LENGTH_SHORT).show();
                    }
                }else {

                    // If it is not a favorite, the place sets its details to the mDetails and its favorite bool to true
                    // It is added to the favorites arrayList and saved to the device
                    // The backup arrayList is also updated and the button changes to a star
                    // Then the discardButton is hidden to prevent any action with it
                    place.setDetails(mDetails);
                    place.setFavorite(true);
                    mFavoritePlaces.add(place);
                    savePlaces(mFavoritePlaces,"favorite");
                    updateTempLocations(place);
                    Toast.makeText(MainActivity.this,"Saved",Toast.LENGTH_SHORT).show();
                    addFavoriteButton.setImageResource(R.drawable.ic_star);
                    discardButton.setVisibility(View.GONE);
                }
            }
        });

        // This checks to see if the place is a favorite or not and removes it from the arraList if it is
        // It changes its favorite bool to false, adds the place to discarded places
        // Then, it removes the marker and saves both the favorite and discarded lists to the device
        // Both buttons are hidden to prevent any activity with them
        discardButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if(place.isFavorite()){
                    int index = 100000;
                    for(int i=0; i<mFavoritePlaces.size();i++){
                        if(Objects.equals(mFavoritePlaces.get(i).getId(), place.getId())){
                            index = i;
                        }
                    }
                    if(index != 100000){
                        mFavoritePlaces.remove(index);
                        place.setFavorite(false);
                        mDiscardedPlaces.add(place);
                        marker.remove();
                        savePlaces(mFavoritePlaces,"favorite");
                        savePlaces(mDiscardedPlaces,"discard");
                        addFavoriteButton.setVisibility(View.GONE);
                        discardButton.setVisibility(View.GONE);
                        Toast.makeText(MainActivity.this,"Discarded",Toast.LENGTH_SHORT).show();
                    }
                }else{

                    // If it is not a favorite, it sets the details to it and the favorites bool to false
                    // It adds the place to the discarded places and removes the marker
                    // Then, it saves the discarded places to the device and hides both buttons
                    place.setDetails(mDetails);
                    place.setFavorite(false);
                    mDiscardedPlaces.add(place);
                    marker.remove();
                    savePlaces(mDiscardedPlaces,"discard");
                    addFavoriteButton.setVisibility(View.GONE);
                    discardButton.setVisibility(View.GONE);
                    Toast.makeText(MainActivity.this,"Discarded",Toast.LENGTH_SHORT).show();
                }
            }
        });

        alertDialog.setPositiveButton("Cancel", new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialog, int which) {
                dialog.cancel();
            }
        });

        alertDialog.show();
    }

    // This loops through all of the places and sets the favorite bool to current status if the ids equal
    // Then it saves the places by the user's longitude to be retrieved again at another time
    private void updateTempLocations(Place place){
        for(Place p: mPlaces){
            if(Objects.equals(place.getId(), p.getId())){
                p.setFavorite(place.isFavorite());
            }
        }
        savePlaces(mPlaces,String.valueOf(mUserLocation.longitude));
    }

    // This saves all of the places for the MainActivity
    // It was created and used before the dataHandler was created
    private void savePlaces(ArrayList<Place> places, String type){
        try {
            FileOutputStream fileOutputStream = openFileOutput(type,MODE_PRIVATE);
            ObjectOutputStream objectOutputStream = new ObjectOutputStream(fileOutputStream);
            objectOutputStream.writeObject(places);
            objectOutputStream.close();
            fileOutputStream.close();
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    // This loads all of the places for the MainActivity
    private ArrayList<Place> loadPlaces(String type){
        ArrayList<Place> places = null;
        try {
            FileInputStream fileInputStream = openFileInput(type);
            ObjectInputStream objectInputStream = new ObjectInputStream(fileInputStream);
            //noinspection unchecked
            places = (ArrayList<Place>)objectInputStream.readObject();
            objectInputStream.close();
            fileInputStream.close();
        } catch (IOException | ClassNotFoundException e) {
            e.printStackTrace();
        }
        return places;
    }


}
