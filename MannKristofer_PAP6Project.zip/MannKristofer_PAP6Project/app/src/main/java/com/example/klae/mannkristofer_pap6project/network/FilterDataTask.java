// Kristofer Mann
// PAP6 - 1802
// FilterDataTask.java
package com.example.klae.mannkristofer_pap6project.network;

import android.content.Context;
import android.os.AsyncTask;

import com.example.klae.mannkristofer_pap6project.data.DataHandler;
import com.example.klae.mannkristofer_pap6project.objects.Place;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.util.ArrayList;

// This is where we retrieve the filtered search data from the Google Places Web API
public class FilterDataTask extends AsyncTask<Void,Void,ArrayList<Place>> {

    private final Context mContext;
    private String mLocation = "";
    private String mRadius = "&radius=";
    private String mCost = "&maxprice";
    private final String mRating;

    // This receives a context, user location, radius, cost, and rating filter and sets their variables
    public FilterDataTask(Context context, String location, String radius, String cost, String rating){
        mContext = context;
        mLocation = location;
        mRadius += radius;
        mCost = cost;
        mRating = rating;
    }

    // This returns a list of places after the NetworkUtilities gets the string from the url
    // getPlaces is provided the string data and parses through it
    @Override
    protected ArrayList<Place> doInBackground(Void... params) {
        ArrayList<Place> places;
        String mKey = "&key=AIzaSyC_NdBwpYCegNicZGxECXmJN1p9wL7vCwc";
        String mURL = "https://maps.googleapis.com/maps/api/place/nearbysearch/json?type=restaurant&type=food&location=";
        String data = NetworkUtilities
                .getDataString(mURL + mLocation + mRadius + mCost + mKey);
        places = getPlaces(data);
        return places;
    }

    // This returns an arrayList of places after it loops through all of the location in the JSON data
    // It retrieves all of the necessary strings to create a place object
    // It also retrieves a rating if there  is one there to be used in the onPostExecute
    private ArrayList<Place> getPlaces(String data){
        ArrayList<Place> places = new ArrayList<>();
        try {
            JSONObject jsonObject = new JSONObject(data);
            JSONArray jsonArray = jsonObject.getJSONArray("results");
            for(int i=0;i<jsonArray.length();i++) {
                JSONObject object = jsonArray.getJSONObject(i);
                String rating ="0";
                if(object.has("rating")){
                    rating = object.getString("rating");
                }
                JSONObject geometry = object.getJSONObject("geometry");
                JSONObject location = geometry.getJSONObject("location");
                String lat = location.getString("lat");
                String lng = location.getString("lng");
                String name = object.getString("name");
                String id = object.getString("place_id");
                Place place = new Place(lat,lng,name,id,false);
                place.setRating(rating);
                places.add(place);
            }

            return places;
        } catch (JSONException e) {
            e.printStackTrace();
        }
        return null;
    }

    // This creates a new dataHandler to save the update bool and places
    @Override
    protected void onPostExecute(ArrayList<Place> places) {
        super.onPostExecute(places);
        DataHandler dataHandler = new DataHandler();

        // This loops through each of the places, converts their ratings to Doubles, then compares them to rating filter
        // An integer arrayList is created to store all of the index locations of places with ratings less than the filter
        if(mRating != null){
            Double rating = Double.parseDouble(mRating);
            ArrayList<Integer> index = new ArrayList<>();
            for(int i=0;i<places.size();i++){
                Double r = Double.parseDouble(places.get(i).getRating());
                if(r < rating){
                    index.add(i);
                }
            }

            // This loops through the index arrayList backwards while storing the integer inside of in an int
            // The int is then used as a reference to remove an item from the list
            // This has to loop backwards to prevent incorrect places from being removed
            if(!index.isEmpty()){
                for(int i = index.size() - 1; i >=0; i--){
                    int j = index.get(i);
                    places.remove(j);
                }
            }

        }
        dataHandler.saveUpdateBool(mContext,true,"update");
        dataHandler.savePlaces(mContext, places,"filterplaces");
    }
}
