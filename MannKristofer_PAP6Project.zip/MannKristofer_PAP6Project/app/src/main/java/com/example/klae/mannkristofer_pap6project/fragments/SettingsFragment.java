// Kristofer Mann
// PAP6 - 1802
// SettingsFragment
package com.example.klae.mannkristofer_pap6project.fragments;

import android.app.Fragment;
import android.content.Intent;
import android.os.Bundle;
import android.support.annotation.Nullable;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;

import com.example.klae.mannkristofer_pap6project.BlockedLocationsActivity;
import com.example.klae.mannkristofer_pap6project.LocationDataActivity;
import com.example.klae.mannkristofer_pap6project.MainActivity;
import com.example.klae.mannkristofer_pap6project.R;
import com.example.klae.mannkristofer_pap6project.SearchFilterActivity;
import com.google.android.gms.maps.model.LatLng;


public class SettingsFragment extends Fragment {

    private static final String ARGS_LOCATION = "ARGS_LOCATION";

    // This receives a LatLng of the user's current location to be provided to other fragments
    // This was before the dataHandler was created to perform such a function
    public static SettingsFragment newInstance(LatLng latLng) {
        
        Bundle args = new Bundle();
        args.putParcelable(ARGS_LOCATION,latLng);
        
        SettingsFragment fragment = new SettingsFragment();
        fragment.setArguments(args);
        return fragment;
    }

    @Nullable
    @Override
    public View onCreateView(LayoutInflater inflater, @Nullable ViewGroup container, Bundle savedInstanceState) {
        return inflater.inflate(R.layout.fragment_settings,container,false);
    }

    // This is where each of the setting's buttons display their associated screens with a click
    // It retrieves the user's location from args then assigns each button to their associated id
    @Override
    public void onActivityCreated(@Nullable Bundle savedInstanceState) {
        super.onActivityCreated(savedInstanceState);

        final LatLng latLng = getArguments().getParcelable(ARGS_LOCATION);

        // This takes the user to the search filter screen
        @SuppressWarnings("ConstantConditions") Button searchFilterButton = (Button)getView().findViewById(R.id.searchFilter_button);
        searchFilterButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(getContext(), SearchFilterActivity.class);
                getContext().startActivity(intent);
            }
        });

        // This takes the user to the location data screen
        // It provides the intent with the user's location
        Button locationDataButton = (Button)getView().findViewById(R.id.locationData_button);
        locationDataButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(getContext(), LocationDataActivity.class);
                Bundle args = new Bundle();
                args.putParcelable(MainActivity.ARGS_BUNDLE,latLng);
                intent.putExtra(MainActivity.EXTRA_LOCATION,args);
                getContext().startActivity(intent);
            }
        });

        // This takes the user to the blocked locations screen
        // It provides the intent with the user's location
        Button blockedLocationsButton = (Button)getView().findViewById(R.id.blockedLocations_button);
        blockedLocationsButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(getContext(), BlockedLocationsActivity.class);
                Bundle args = new Bundle();
                args.putParcelable(MainActivity.ARGS_BUNDLE,latLng);
                intent.putExtra(MainActivity.EXTRA_LOCATION,args);
                getContext().startActivity(intent);
            }
        });

    }
}
