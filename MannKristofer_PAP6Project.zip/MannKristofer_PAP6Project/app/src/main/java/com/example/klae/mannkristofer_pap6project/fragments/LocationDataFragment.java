// Kristofer Mann
// PAP6 - 1802
// LocationDataFragment.java
package com.example.klae.mannkristofer_pap6project.fragments;

import android.app.AlertDialog;
import android.app.Fragment;
import android.content.DialogInterface;
import android.os.Bundle;
import android.support.annotation.Nullable;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.EditText;
import android.widget.ImageButton;
import android.widget.ListView;

import com.example.klae.mannkristofer_pap6project.R;
import com.example.klae.mannkristofer_pap6project.adapter.ChangeSearchLocationAdapter;
import com.example.klae.mannkristofer_pap6project.adapter.SavedLocationsAdapter;
import com.example.klae.mannkristofer_pap6project.data.DataHandler;
import com.example.klae.mannkristofer_pap6project.objects.Place;
import com.google.android.gms.maps.model.LatLng;

import java.util.ArrayList;

public class LocationDataFragment extends Fragment {

    private static final String ARGS_LOCATION = "ARGS_LOCATION";

    // This retrieves a LatLng of the user's location and adds it to args
    public static LocationDataFragment newInstance(LatLng latLng) {

        Bundle args = new Bundle();
        args.putParcelable(ARGS_LOCATION,latLng);

        LocationDataFragment fragment = new LocationDataFragment();
        fragment.setArguments(args);
        return fragment;
    }

    // Sets the view to that of the desired layout
    @Nullable
    @Override
    public View onCreateView(LayoutInflater inflater, @Nullable ViewGroup container, Bundle savedInstanceState) {
        return inflater.inflate(R.layout.fragment_location_data,container,false);
    }

    // This sets up the UI and retrieves the user's location from args
    @Override
    public void onActivityCreated(@Nullable Bundle savedInstanceState) {
        super.onActivityCreated(savedInstanceState);

        final DataHandler dataHandler = new DataHandler();
        final LatLng latLng = getArguments().getParcelable(ARGS_LOCATION);

        // The location places are loaded from the dataHandler
        // Then the custom adapter is set to the listView providing it the context and locations
        final ArrayList<Place> places = dataHandler.loadPlaces(getContext(),"location");
        @SuppressWarnings("ConstantConditions") final ListView locationListView = (ListView)getView().findViewById(R.id.savedLocations_listView);
        final SavedLocationsAdapter adapter = new SavedLocationsAdapter(getContext(),places);
        locationListView.setAdapter(adapter);

        // This allows the user to change the location of the search
        // An alertDialog is used to display the list of locations with a check box to be selected
        // The dialog's view is set to the desired layout and allows for it to be cancelable
        ImageButton changeButton = (ImageButton)getView().findViewById(R.id.changeSearch_button);
        changeButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                AlertDialog.Builder alertDialog = new AlertDialog.Builder(getContext());
                LayoutInflater layoutInflater = getActivity().getLayoutInflater();
                final View view = layoutInflater.inflate(R.layout.change_search_listview,null);
                alertDialog.setView(view);
                alertDialog.setCancelable(true);
                alertDialog.setTitle("Search Location");

                // This creates the listView and retrieves the places from the dataHandler
                // It retrieves the places again just in case the user deleted a location from the manage saved section
                // The listView sets its adapter while providing it the context, locations, and user's location
                ListView searchChangedListView = (ListView)view.findViewById(R.id.searchChanged_listView);
                final ArrayList<Place> searchPlaces = dataHandler.loadPlaces(getContext(),"location");
                @SuppressWarnings("ConstantConditions") Place currentLocation = new Place(String.valueOf(latLng.latitude),String.valueOf(latLng.longitude),
                        "current location",String.valueOf(latLng.latitude),false);
                final ChangeSearchLocationAdapter searchAdapter = new ChangeSearchLocationAdapter(getContext(),searchPlaces,currentLocation);
                searchChangedListView.setAdapter(searchAdapter);

                // This closes the dialog whether a selection was made or not
                // The location is saved within the custom adapter class
                alertDialog.setPositiveButton("OK", new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialog, int which) {
                        dialog.cancel();
                    }
                });
                alertDialog.show();
            }
        });

        // This button provides an alertDialog with an editText for the user to save a location
        // It saves the current location for the user to change or manage later
        ImageButton saveButton = (ImageButton)getView().findViewById(R.id.save_button);
        saveButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                // The alertDialog sets it view to that of a custom one by the desired layout
                final AlertDialog.Builder alertDialog = new AlertDialog.Builder(getContext());
                LayoutInflater layoutInflater = getActivity().getLayoutInflater();
                final View view = layoutInflater.inflate(R.layout.save_location_view,null);
                alertDialog.setView(view);
                alertDialog.setCancelable(true);
                alertDialog.setTitle("Save Current Location");

                // The editText is set by its id and the alertDialog creates a new button
                // It then creates a new place object by the LatLng data
                final EditText saveLocationEditText = (EditText)view.findViewById(R.id.saveLocation_editText);
                alertDialog.setPositiveButton("Save", new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialog, int which) {
                        @SuppressWarnings("ConstantConditions") Place place = new Place(String.valueOf(latLng.latitude),String.valueOf(latLng.longitude),
                                saveLocationEditText.getText().toString(),String.valueOf(latLng.latitude),false);

                        // An arrayList is created to obtain saved location data
                        // It creates a new one if that data was null
                        // Then it adds the place to the list and saves it
                        @SuppressWarnings("Convert2Diamond") ArrayList<Place> places;
                        places = dataHandler.loadPlaces(getContext(),"location");
                        if(places == null){
                            //noinspection Convert2Diamond
                            places = new ArrayList<Place>();
                        }
                        places.add(place);
                        dataHandler.savePlaces(getContext(),places,"location");

                        // A new adapter is created and set to the listView to refresh it with the new location
                        SavedLocationsAdapter refreshAdapter = new SavedLocationsAdapter(getContext(),places);
                        locationListView.setAdapter(refreshAdapter);
                        dialog.dismiss();
                    }
                });
                alertDialog.setNegativeButton("Cancel", new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialog, int which) {
                        dialog.cancel();
                    }
                });

                alertDialog.show();
            }
        });


    }
}
