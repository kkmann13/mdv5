// Kristofer Mann
// PAP6 - 1802
// SavedLocationsAdapter
package com.example.klae.mannkristofer_pap6project.adapter;

import android.content.Context;
import android.content.DialogInterface;
import android.support.v7.app.AlertDialog;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.ImageButton;
import android.widget.TextView;

import com.example.klae.mannkristofer_pap6project.R;
import com.example.klae.mannkristofer_pap6project.data.DataHandler;
import com.example.klae.mannkristofer_pap6project.objects.Place;

import java.util.ArrayList;

// Custom adapter for the LocationDataFragment's listView
public class SavedLocationsAdapter extends BaseAdapter {

    private final Context mContext;
    private final ArrayList<Place> mPlaces;

    // Constructor to receive a context and an arrayList of places
    public SavedLocationsAdapter(Context mContext, ArrayList<Place> mPlaces) {
        this.mContext = mContext;
        this.mPlaces = mPlaces;
    }

    // Returns the number of items in the arraList
    @Override
    public int getCount() {
        if(mPlaces != null){
            return mPlaces.size();
        }
        return 0;
    }

    // Returns the place within that position
    @Override
    public Place getItem(int position) {
        if(mPlaces != null && position<mPlaces.size() && position>=0){
            return  mPlaces.get(position);
        }
        return null;
    }

    @Override
    public long getItemId(int position) {
        return position;
    }

    // It sets the view to the layout then applies it to the viewHolder
    @Override
    public View getView(final int position, View convertView, ViewGroup parent) {
        ViewHolder viewHolder;
        if(convertView == null){
            convertView = LayoutInflater.from(mContext).inflate(R.layout.save_location_listview,parent,false);
            viewHolder = new ViewHolder(convertView);
            convertView.setTag(viewHolder);
        }else {
            viewHolder = (ViewHolder)convertView.getTag();
        }

        // Retrieves the place within the arrayList
        Place place = getItem(position);

        // Sets the name to the textView
        viewHolder.locationTextView.setText(place.getName());

        // Sets the onClickListener for the delete button
        // It provides an alertDialog to confirm whether or not the user wants to delete the location
        // Pressing delete will create a new dataHandler to save the updated arrayList of locations
        // Then, the adapter is updated with fresh data
        viewHolder.deleteButtton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                AlertDialog.Builder builder = new AlertDialog.Builder(mContext);
                builder.setTitle("Delete Location?");
                builder.setPositiveButton("Cancel", new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialog, int which) {
                        dialog.cancel();
                    }
                });

                builder.setNegativeButton("Delete", new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialog, int which) {

                        DataHandler dataHandler = new DataHandler();
                        mPlaces.remove(position);
                        dataHandler.savePlaces(mContext,mPlaces,"location");
                        notifyDataSetChanged();
                    }
                });
                builder.show();
            }
        });

        return convertView;
    }

    // A view holder is used to make presenting the textView and imageButton more efficient
    private static class ViewHolder {
        private final TextView locationTextView;
        private final ImageButton deleteButtton;

        private ViewHolder(View v){
            locationTextView = (TextView)v.findViewById(R.id.location_textView);
            deleteButtton = (ImageButton)v.findViewById(R.id.deleteLocation_button);
        }
    }

}
