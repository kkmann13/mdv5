// Kristofer Mann
// PAP6 - 1802
// SearchFilterFragment.java
package com.example.klae.mannkristofer_pap6project.fragments;

import android.app.Fragment;
import android.content.Context;
import android.os.Bundle;
import android.support.annotation.Nullable;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.CompoundButton;
import android.widget.SeekBar;
import android.widget.Switch;
import android.widget.TextView;

import com.example.klae.mannkristofer_pap6project.R;
import com.example.klae.mannkristofer_pap6project.data.DataHandler;
import com.example.klae.mannkristofer_pap6project.objects.Filter;

// This allows the user to get new search results based upon a filter
public class SearchFilterFragment extends Fragment {

    private SearchFilterListener mListener;

    // interface used to update the SearchFilterActivity variables
    public interface SearchFilterListener{
        void setRadius(String radius);
        void setRating(String rating);
        void setCost(String cost);
    }

    public static SearchFilterFragment newInstance() {

        Bundle args = new Bundle();

        SearchFilterFragment fragment = new SearchFilterFragment();
        fragment.setArguments(args);
        return fragment;
    }

    @Nullable
    @Override
    public View onCreateView(LayoutInflater inflater, @Nullable ViewGroup container, Bundle savedInstanceState) {
        return inflater.inflate(R.layout.fragment_search_filter,container,false);
    }

    // Checks to see if the Activity implements the listener
    @Override
    public void onAttach(Context context) {
        super.onAttach(context);
        if(context instanceof SearchFilterListener){
            mListener = (SearchFilterListener)context;
        }
    }

    @Override
    public void onActivityCreated(@Nullable Bundle savedInstanceState) {
        super.onActivityCreated(savedInstanceState);

        @SuppressWarnings("ConstantConditions") final TextView radiusTextView = (TextView)getView().findViewById(R.id.radius_textView);
        final SeekBar radiusSeekBar = (SeekBar)getView().findViewById(R.id.radius_seekBar);
        Switch radiusSwitch = (Switch)getView().findViewById(R.id.radius_switch);

        // Disables the seekBar so that it cannot used unless desired
        radiusSeekBar.setEnabled(false);

        // It checks the state of the switch then either enables or disables the seekBar
        // If its checked, then it gets the progress of the seekBar and sets the textView to that integer
        // Then the listener's method is called to update the Activity with the radius
        // If it is not checked, then it calls the listener's method to update the Activity with null
        radiusSwitch.setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener() {
            @Override
            public void onCheckedChanged(CompoundButton buttonView, boolean isChecked) {
                if(isChecked){
                    radiusSeekBar.setEnabled(true);
                    String progress;
                    if(radiusSeekBar.getProgress() == 0){
                        progress = String.valueOf(radiusSeekBar.getProgress() + 1);
                    }else {
                        progress = String.valueOf(radiusSeekBar.getProgress());
                    }
                    radiusTextView.setText("Radius: " + progress + " mi.");
                    mListener.setRadius(progress);
                }else{
                    radiusSeekBar.setEnabled(false);
                    radiusTextView.setText(R.string.radius_off);
                    mListener.setRadius(null);
                }
            }
        });

        // This gets the progress of the seekBar when the thumb changes positions
        // It sets the integer to the textView to show live results to the user
        // When it stops, it calls the listener's method to provide the Activity with the radius
        radiusSeekBar.setOnSeekBarChangeListener(new SeekBar.OnSeekBarChangeListener() {
            @Override
            public void onProgressChanged(SeekBar seekBar, int progress, boolean fromUser) {
                progress +=1;
                radiusTextView.setText("Radius: " + progress + " mi.");
            }

            @Override
            public void onStartTrackingTouch(SeekBar seekBar) {

            }

            @Override
            public void onStopTrackingTouch(SeekBar seekBar) {
                mListener.setRadius(String.valueOf(seekBar.getProgress() + 1));
            }
        });

        final TextView ratingTextView = (TextView)getView().findViewById(R.id.rating_textView);
        final SeekBar ratingSeekBar = (SeekBar)getView().findViewById(R.id.ratings_seekBar);
        Switch ratingSwitch = (Switch)getView().findViewById(R.id.rating_switch);

        // Disables the seekBar so that it cannot used unless desired
        ratingSeekBar.setEnabled(false);

        // It checks the state of the switch then either enables or disables the seekBar
        // If its checked, then it gets the progress of the seekBar and sets the textView to that integer
        // Then the listener's method is called to update the Activity with the rating
        // If it is not checked, then it calls the listener's method to update the Activity with null
        ratingSwitch.setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener() {
            @Override
            public void onCheckedChanged(CompoundButton buttonView, boolean isChecked) {
                if(isChecked){
                    ratingSeekBar.setEnabled(true);
                    String progress = String.valueOf(ratingSeekBar.getProgress());
                    ratingTextView.setText("Ratings: >= " + progress);
                    mListener.setRating(progress);
                }else {
                    ratingSeekBar.setEnabled(false);
                    ratingTextView.setText(R.string.ratings_off);
                    mListener.setRating(null);
                }
            }
        });

        // This gets the progress of the seekBar when the thumb changes positions
        // It sets the integer to the textView to show live results to the user
        // When it stops, it calls the listener's method to provide the Activity with the rating
        ratingSeekBar.setOnSeekBarChangeListener(new SeekBar.OnSeekBarChangeListener() {
            @Override
            public void onProgressChanged(SeekBar seekBar, int progress, boolean fromUser) {
                ratingTextView.setText("Ratings: >=" + progress);
            }

            @Override
            public void onStartTrackingTouch(SeekBar seekBar) {

            }

            @Override
            public void onStopTrackingTouch(SeekBar seekBar) {
                mListener.setRating(String.valueOf(seekBar.getProgress()));
            }
        });

        final TextView costTextView = (TextView)getView().findViewById(R.id.cost_textView);
        final SeekBar costSeekBar = (SeekBar)getView().findViewById(R.id.cost_seekBar);
        final Switch costSwitch = (Switch)getView().findViewById(R.id.cost_switch);

        // Disables the seekBar so that it cannot used unless desired
        costSeekBar.setEnabled(false);

        // It checks the state of the switch then either enables or disables the seekBar
        // If its checked, then it gets the progress of the seekBar and sets the textView to that integer
        // Then the listener's method is called to update the Activity with the cost level
        // If it is not checked, then it calls the listener's method to update the Activity with null
        costSwitch.setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener() {
            @Override
            public void onCheckedChanged(CompoundButton buttonView, boolean isChecked) {
                if(isChecked){
                    costSeekBar.setEnabled(true);
                    costTextView.setText("Cost Level: <=" + costSeekBar.getProgress());
                    mListener.setCost(String.valueOf(costSeekBar.getProgress()));
                }else {
                    costSeekBar.setEnabled(false);
                    costTextView.setText(R.string.cost_off);
                    mListener.setCost(null);
                }
            }
        });

        // This gets the progress of the seekBar when the thumb changes positions
        // It sets the integer to the textView to show live results to the user
        // When it stops, it calls the listener's method to provide the Activity with the cost level
        costSeekBar.setOnSeekBarChangeListener(new SeekBar.OnSeekBarChangeListener() {
            @Override
            public void onProgressChanged(SeekBar seekBar, int progress, boolean fromUser) {
                costTextView.setText("Cost Level: <=" + progress);
            }

            @Override
            public void onStartTrackingTouch(SeekBar seekBar) {

            }

            @Override
            public void onStopTrackingTouch(SeekBar seekBar) {
                mListener.setCost(String.valueOf(seekBar.getProgress()));
            }
        });

        // A new dataHandler to retrieve the saved filter
        // This is so we can present the UI with the current filter setting
        DataHandler dataHandler = new DataHandler();
        Filter filter = dataHandler.loadFilter(getContext(),"filter");

        // This retrieves each of the filter items
        // It sets each of their associated UI elements to that of what was saved as a filter
        // Null will disable the seekBar and turn off the switch
        // Otherwise the switch will be on and the progress of the seekBars are set to the integer saved as a string
        if(filter != null){
            if(filter.getRadius()!=null){
                radiusSwitch.setChecked(true);
                radiusSeekBar.setEnabled(true);
                radiusSeekBar.setProgress(Integer.parseInt(filter.getRadius()));
                radiusTextView.setText("Radius: " + radiusSeekBar.getProgress() + " mi.");
                mListener.setRadius(String.valueOf(radiusSeekBar.getProgress()));
            }
            if(filter.getRating()!=null){
                ratingSwitch.setChecked(true);
                ratingSeekBar.setEnabled(true);
                ratingSeekBar.setProgress(Integer.parseInt(filter.getRating()));
                ratingTextView.setText("Ratings: >=" + ratingSeekBar.getProgress());
                mListener.setRating(String.valueOf(ratingSeekBar.getProgress()));
            }
            if(filter.getCost()!=null){
                costSwitch.setChecked(true);
                costSeekBar.setEnabled(true);
                costSeekBar.setProgress(Integer.parseInt(filter.getCost()));
                costTextView.setText("Cost Level: <=" + costSeekBar.getProgress());
                mListener.setCost(String.valueOf(costSeekBar.getProgress()));
            }

        }

    }

}
