// Kristofer Mann
// PAP6 - 1802
// BlockedLocationsActivity.java
package com.example.klae.mannkristofer_pap6project;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;

import com.example.klae.mannkristofer_pap6project.fragments.BlockedLocationsMapFragment;
import com.example.klae.mannkristofer_pap6project.objects.Place;
import com.google.android.gms.maps.model.LatLng;

import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.util.ArrayList;

public class BlockedLocationsActivity extends AppCompatActivity implements BlockedLocationsMapFragment.BlockedLocationsListener {

    // This gets the user's location from the settings screen and
    // it gets the discarded and favorite places arrayLists from the associated methods
    // This was all set up before the dataHandler was created
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_blocked_locations);

        Bundle bundle = getIntent().getParcelableExtra(MainActivity.EXTRA_LOCATION);
        LatLng latLng = bundle.getParcelable(MainActivity.ARGS_BUNDLE);

        ArrayList<Place> discardedPlaces;
        discardedPlaces = loadPlaces("discard");

        ArrayList<Place> favoritePlaces;
        favoritePlaces = loadPlaces("favorite");

        // Provides the user's location, discarded places, and favorite places to the fragment
        getFragmentManager().beginTransaction().replace(R.id.fragment_container, BlockedLocationsMapFragment.newInstance(latLng,discardedPlaces,favoritePlaces)).commit();
    }

    // Saves places when blocked locations change
    public void savePlaces(ArrayList<Place> places, String type){
        try {
            FileOutputStream fileOutputStream = openFileOutput(type,MODE_PRIVATE);
            ObjectOutputStream objectOutputStream = new ObjectOutputStream(fileOutputStream);
            objectOutputStream.writeObject(places);
            objectOutputStream.close();
            fileOutputStream.close();
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    // Loads blocked locations to be presented on the map
    private ArrayList<Place> loadPlaces(String type){
        ArrayList<Place> places = null;
        try {
            FileInputStream fileInputStream = openFileInput(type);
            ObjectInputStream objectInputStream = new ObjectInputStream(fileInputStream);
            //noinspection unchecked
            places = (ArrayList<Place>)objectInputStream.readObject();
            objectInputStream.close();
            fileInputStream.close();
        } catch (IOException | ClassNotFoundException e) {
            e.printStackTrace();
        }
        return places;
    }
}
