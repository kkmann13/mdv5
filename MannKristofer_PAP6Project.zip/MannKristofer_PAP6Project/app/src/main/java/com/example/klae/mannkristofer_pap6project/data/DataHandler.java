// Kristofer Mann
// PAP6 - 1802
// DataHandler.java
package com.example.klae.mannkristofer_pap6project.data;

import android.content.Context;

import com.example.klae.mannkristofer_pap6project.objects.Filter;
import com.example.klae.mannkristofer_pap6project.objects.Place;

import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.util.ArrayList;

// This class is used to handle all saving and loading of data outside of the MainActivity
public class DataHandler {

    // Saves a bool so the system can check if a filter update happened or not
    public void saveUpdateBool(Context context, boolean update, @SuppressWarnings("SameParameterValue") String type){
        try {
            @SuppressWarnings("AccessStaticViaInstance") FileOutputStream fileOutputStream = context.openFileOutput(type,context.MODE_PRIVATE);
            ObjectOutputStream objectOutputStream = new ObjectOutputStream(fileOutputStream);
            objectOutputStream.writeObject(update);
            objectOutputStream.close();
            fileOutputStream.close();
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    // Loads a bool so that the system can check if the map needs to be updated with the filter results
    public boolean loadUpdateBool(Context context, @SuppressWarnings("SameParameterValue") String type){
        boolean update = false;
        try {
            FileInputStream fileInputStream = context.openFileInput(type);
            ObjectInputStream objectInputStream = new ObjectInputStream(fileInputStream);
            update = (boolean) objectInputStream.readObject();
            objectInputStream.close();
            fileInputStream.close();
        } catch (IOException | ClassNotFoundException e) {
            e.printStackTrace();
        }
        return update;
    }

    // Saves the Filter object to be referenced by the search filter screen
    // This allows for the settings to be saved automatically
    public void saveFilter(Context context, Filter filter, @SuppressWarnings("SameParameterValue") String type){
        try {
            @SuppressWarnings("AccessStaticViaInstance") FileOutputStream fileOutputStream = context.openFileOutput(type,context.MODE_PRIVATE);
            ObjectOutputStream objectOutputStream = new ObjectOutputStream(fileOutputStream);
            objectOutputStream.writeObject(filter);
            objectOutputStream.close();
            fileOutputStream.close();
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    // Loads the Filter to display saved settings in the search filter screen
    public Filter loadFilter(Context context, @SuppressWarnings("SameParameterValue") String type){
        Filter filter = null;
        try {
            FileInputStream fileInputStream = context.openFileInput(type);
            ObjectInputStream objectInputStream = new ObjectInputStream(fileInputStream);
            filter = (Filter) objectInputStream.readObject();
            objectInputStream.close();
            fileInputStream.close();
        } catch (IOException | ClassNotFoundException e) {
            e.printStackTrace();
        }
        return filter;
    }

    // Saves a location to be referenced
    public void saveLocation(Context context, Place place, @SuppressWarnings("SameParameterValue") String type){
        try {
            @SuppressWarnings("AccessStaticViaInstance") FileOutputStream fileOutputStream = context.openFileOutput(type,context.MODE_PRIVATE);
            ObjectOutputStream objectOutputStream = new ObjectOutputStream(fileOutputStream);
            objectOutputStream.writeObject(place);
            objectOutputStream.close();
            fileOutputStream.close();
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    // Loads a saved location
    public Place loadLocation(Context context, @SuppressWarnings("SameParameterValue") String type){
        Place place = null;
        try {
            FileInputStream fileInputStream = context.openFileInput(type);
            ObjectInputStream objectInputStream = new ObjectInputStream(fileInputStream);
            place = (Place) objectInputStream.readObject();
            objectInputStream.close();
            fileInputStream.close();
        } catch (IOException | ClassNotFoundException e) {
            e.printStackTrace();
        }
        return place;
    }

    // Saves an arrayList of places to be retrieved
    public void savePlaces(Context context, ArrayList<Place> places, String type){
        try {
            @SuppressWarnings("AccessStaticViaInstance") FileOutputStream fileOutputStream = context.openFileOutput(type,context.MODE_PRIVATE);
            ObjectOutputStream objectOutputStream = new ObjectOutputStream(fileOutputStream);
            objectOutputStream.writeObject(places);
            objectOutputStream.close();
            fileOutputStream.close();
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    // Loads an arrayList of places
    public ArrayList<Place> loadPlaces(Context context, String type){
        ArrayList<Place> places = null;
        try {
            FileInputStream fileInputStream = context.openFileInput(type);
            ObjectInputStream objectInputStream = new ObjectInputStream(fileInputStream);
            //noinspection unchecked
            places = (ArrayList<Place>)objectInputStream.readObject();
            objectInputStream.close();
            fileInputStream.close();
        } catch (IOException | ClassNotFoundException e) {
            e.printStackTrace();
        }
        return places;
    }

}
