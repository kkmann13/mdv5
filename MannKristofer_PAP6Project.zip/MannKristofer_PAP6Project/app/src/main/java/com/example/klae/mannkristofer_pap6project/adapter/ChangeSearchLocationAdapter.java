// Kristofer Mann
// PAP6 - 1802
// ChangeSearchLocationAdapter.java
package com.example.klae.mannkristofer_pap6project.adapter;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.ImageButton;
import android.widget.TextView;

import com.example.klae.mannkristofer_pap6project.R;
import com.example.klae.mannkristofer_pap6project.data.DataHandler;
import com.example.klae.mannkristofer_pap6project.objects.Place;

import java.util.ArrayList;

// Custom adapter for the LocationDataFragment's change search button
public class ChangeSearchLocationAdapter extends BaseAdapter {

    private final Context mContext;
    private final ArrayList<Place> mPlaces;
    private final Place mCurrentLocation;
    private boolean mChecked = false;
    private int mPosition=0;

    // Constructor to receive a context, arrayList, and current user location
    public ChangeSearchLocationAdapter(Context mContext, ArrayList<Place> mPlaces, Place mCurrentLocation) {
        this.mContext = mContext;
        this.mPlaces = mPlaces;
        this.mCurrentLocation = mCurrentLocation;
    }

    // Returns the count
    @Override
    public int getCount() {
        if(mPlaces != null){
            return mPlaces.size();
        }
        return 0;
    }

    // Returns the place at a certain position
    @Override
    public Place getItem(int position) {
        if(mPlaces != null && position<mPlaces.size() && position>=0){
            return  mPlaces.get(position);
        }
        return null;
    }

    @Override
    public long getItemId(int position) {
        return position;
    }

    // It sets the view to the layout then applies it to the viewHolder
    @Override
    public View getView(final int position, View convertView, ViewGroup parent) {
        final ViewHolder viewHolder;
        if(convertView == null){
            convertView = LayoutInflater.from(mContext).inflate(R.layout.change_search_view,parent,false);
            viewHolder = new ViewHolder(convertView);
            convertView.setTag(viewHolder);
        }else {
            viewHolder = (ViewHolder) convertView.getTag();
        }

        // Retrieves the place at that position and sets the textView to the name
        final Place place = getItem(position);
        viewHolder.changeSearchTextView.setText(place.getName());

        // Sets the button's onClickListener and creates a new dataHandler
        viewHolder.checkButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                DataHandler dataHandler = new DataHandler();

                // This checks to see if the position has changed or the mChecked bool is true
                // If it has not changed and it is true, then changes the image of the button
                // Then it updates the bool and adapter while saving the current location with the dataHandler
                // If nothing is checked, then it retrieves the position and sets it the variable
                // It changes the image to that of a checked box, sets the bool to true, and saves the current location
                if(mPosition == position && mChecked){
                    viewHolder.checkButton.setImageResource(R.drawable.ic_check_box_outline);
                    mChecked = false;
                    notifyDataSetChanged();
                    dataHandler.saveLocation(mContext,mCurrentLocation,"current");
                }else if(!mChecked){
                    mPosition = position;
                    viewHolder.checkButton.setImageResource(R.drawable.ic_check_box);
                    mChecked = true;
                    notifyDataSetChanged();
                    dataHandler.saveLocation(mContext,place,"current");
                }

            }
        });


        return convertView;
    }

    // A view holder is used to make presenting the textView and imageButton more efficient
    private static class ViewHolder {
        private final TextView changeSearchTextView;
        private final ImageButton checkButton;

        private ViewHolder(View v){
            changeSearchTextView = (TextView)v.findViewById(R.id.changeSearch_textView);
            checkButton = (ImageButton)v.findViewById(R.id.check_button);
        }
    }
}
