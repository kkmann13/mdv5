// Kristofer Mann
// PAP6 - 1802
// SearchFilterActivity.java
package com.example.klae.mannkristofer_pap6project;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;

import com.example.klae.mannkristofer_pap6project.data.DataHandler;
import com.example.klae.mannkristofer_pap6project.fragments.SearchFilterFragment;
import com.example.klae.mannkristofer_pap6project.network.FilterDataTask;
import com.example.klae.mannkristofer_pap6project.network.NetworkUtilities;
import com.example.klae.mannkristofer_pap6project.objects.Filter;
import com.example.klae.mannkristofer_pap6project.objects.Place;

public class SearchFilterActivity extends AppCompatActivity implements SearchFilterFragment.SearchFilterListener {

    private Place mUserLocation;
    private String radius;
    private String rating;
    private String cost;

    // This retrieves the user's location from the dataHandler and provides it to the fragment
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_search_filter);

        DataHandler dataHandler = new DataHandler();
        mUserLocation = dataHandler.loadLocation(this,"current");

        getFragmentManager().beginTransaction().add(R.id.fragment_container, SearchFilterFragment.newInstance()).commit();
    }

    // This sets up the data retrieval process when the user leaves the screen
    // It gives the system some time to get the data before the user makes it back to the map
    @Override
    public void onBackPressed() {
        super.onBackPressed();

        // A new filter is created to be saved with the dataHandler
        Filter filter = new Filter(radius,rating,cost);
        DataHandler dataHandler = new DataHandler();
        dataHandler.saveFilter(this,filter,"filter");

        // This prevents anything from happening if all filters are not set
        // Otherwise, it creates a string from the user location
        // It then provides alternative dat if the radius and cost are not set
        // The radius has to multiply its number by 1609 because that is the meter per mile conversion
        // Then, it creates a new FilterDataTask and provides the correct data
        if(radius!=null || rating!=null || cost!=null ){

            NetworkUtilities utilities = new NetworkUtilities();
            if(utilities.isConnected(this)){
                String latLng = String.valueOf(mUserLocation.getLat()) + "," + String.valueOf(mUserLocation.getLng());
                if(radius == null){
                    radius = "9000";
                }else{
                    int r = Integer.parseInt(radius);
                    int m = 1609;
                    r *= m;
                    radius = String.valueOf(r);
                }
                if(cost == null){
                    cost = "&maxprice";
                }else{
                    cost = "&maxprice="+cost;
                }
                FilterDataTask filterDataTask = new FilterDataTask(this,latLng,radius,cost,rating);
                filterDataTask.execute();
            }
        }
    }

    // These set each of the variables from the fragment
    @Override
    public void setRadius(String radius) {
        this.radius = radius;
    }

    @Override
    public void setRating(String rating) {
        this.rating = rating;
    }

    @Override
    public void setCost(String cost) {
        this.cost = cost;
    }
}
