// Kristofer Mann
// PAP6 - 1802
// Filter.java
package com.example.klae.mannkristofer_pap6project.objects;

import java.io.Serializable;


public class Filter implements Serializable {

    private final String radius;
    private final String rating;
    private final String cost;

    public Filter(String radius, String rating, String cost) {
        this.radius = radius;
        this.rating = rating;
        this.cost = cost;
    }

    public String getRadius() {
        return radius;
    }

    public String getRating() {
        return rating;
    }

    public String getCost() {
        return cost;
    }
}
