// Kristofer Mann
// PAP6 - 1802
// Details.java
package com.example.klae.mannkristofer_pap6project.objects;


import java.io.Serializable;

public class Details implements Serializable{

    private final String photoURL;
    private final String address;
    private final String number;
    private final String rating;
    private final String priceLevel;
    private final String hours;
    private final String website;

    public Details(String photoURL, String address, String number, String rating, String priceLevel, String hours, String website) {
        this.photoURL = photoURL;
        this.address = address;
        this.number = number;
        this.rating = rating;
        this.priceLevel = priceLevel;
        this.hours = hours;
        this.website = website;
    }

    public String getPhotoURL() {
        return photoURL;
    }

    public String getAddress() {
        return address;
    }

    public String getNumber() {
        return number;
    }

    public String getRating() {
        return rating;
    }

    public String getPriceLevel() {
        return priceLevel;
    }

    public String getHours() {
        return hours;
    }

    public String getWebsite() {
        return website;
    }
}
