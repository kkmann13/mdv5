// Kristofer Mann
// PAP6 - 1802
// DetailsDataTask.java
package com.example.klae.mannkristofer_pap6project.network;

import android.os.AsyncTask;

import com.example.klae.mannkristofer_pap6project.MainActivity;
import com.example.klae.mannkristofer_pap6project.objects.Details;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

// This is where we retrieve the details data from the Google Places Web API
public class DetailsDataTask extends AsyncTask<Void,Void,Details> {

    private final MainActivity mainActivity;
    private String mPlaceId = "";

    // It receives the MainActivity and the place id and sets them to the variables
    public DetailsDataTask(MainActivity activity, String id){
        mainActivity = activity;
        mPlaceId = id;
    }

    // The url place id and key are given to NetworkUtilities to provide back the string data
    // Then, the data is parsed through while storing key detail's strings required to create a details object
    // Not all places have opening hours, so if one is there before it retrieves the weekday hours stings
    // The price level and the website are the same way, so they get predetermined results if not are found
    @Override
    protected Details doInBackground(Void... params) {
        String mURL = "https://maps.googleapis.com/maps/api/place/details/json?placeid=";
        String mKey = "&key=AIzaSyC_NdBwpYCegNicZGxECXmJN1p9wL7vCwc";
        String data = NetworkUtilities
                .getDataString(mURL + mPlaceId + mKey);
        try {
            JSONObject jsonObject = new JSONObject(data);
            JSONObject results = jsonObject.getJSONObject("result");
            String address = results.getString("formatted_address");
            String number = results.getString("formatted_phone_number");
            String rating = results.getString("rating");
            String weekday = "Visit Website For Hours";
            if(results.has("opening_hours")){
                JSONObject hours = results.getJSONObject("opening_hours");
                if(hours.has("weekday_text")){
                    JSONArray jsonArray = hours.getJSONArray("weekday_text");
                    weekday = "";
                    for(int i=0;i<jsonArray.length();i++){
                        weekday += jsonArray.getString(i) + "\n";
                    }
                }
            }
            JSONArray photos = results.getJSONArray("photos");
            JSONObject reference = photos.getJSONObject(0);
            String photoURL = reference.getString("photo_reference");
            String priceLevel = "?";
            if(results.has("price_level")){
                priceLevel = results.getString("price_level");
            }
            String website = "None";
            if(results.has("website")){
                website = results.getString("website");
            }
            return new Details(photoURL,address,number,rating, priceLevel, weekday, website);
        } catch (JSONException e) {
            e.printStackTrace();
        }
        return null;
    }

    // Then sends the data to MainActivity to present to the user
    @Override
    protected void onPostExecute(Details details) {
        super.onPostExecute(details);
        mainActivity.getDetails(details);
    }
}
