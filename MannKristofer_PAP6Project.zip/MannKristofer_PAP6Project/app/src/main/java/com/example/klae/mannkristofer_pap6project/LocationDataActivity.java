// Kristofer Mann
// PAP6 - 1802
// LocationDataActivity.java
package com.example.klae.mannkristofer_pap6project;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;

import com.example.klae.mannkristofer_pap6project.fragments.LocationDataFragment;
import com.google.android.gms.maps.model.LatLng;

public class LocationDataActivity extends AppCompatActivity {

    // This receives the user's location and provides it to the fragment
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_location_data);

        Bundle bundle = getIntent().getParcelableExtra(MainActivity.EXTRA_LOCATION);
        LatLng latLng = bundle.getParcelable(MainActivity.ARGS_BUNDLE);

        getFragmentManager().beginTransaction().add(R.id.fragment_container, LocationDataFragment.newInstance(latLng)).commit();
    }
}
