// Kristofer Mann
// PAP6 - 1802
// SettingsActivity.java
package com.example.klae.mannkristofer_pap6project;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;

import com.example.klae.mannkristofer_pap6project.fragments.SettingsFragment;
import com.google.android.gms.maps.model.LatLng;

public class SettingsActivity extends AppCompatActivity {

    // This retrieves the user's location and provides it to the fragment
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_settings);

        Bundle bundle = getIntent().getParcelableExtra(MainActivity.EXTRA_LOCATION);
        LatLng latLng = bundle.getParcelable(MainActivity.ARGS_BUNDLE);

        getFragmentManager().beginTransaction().add(R.id.fragment_container, SettingsFragment.newInstance(latLng)).commit();
    }

    // This lets the MainActivity know to update all of its data
    @Override
    public void onBackPressed() {
        super.onBackPressed();
        Intent intent = new Intent();
        setResult(RESULT_OK,intent);
        finish();
    }
}
