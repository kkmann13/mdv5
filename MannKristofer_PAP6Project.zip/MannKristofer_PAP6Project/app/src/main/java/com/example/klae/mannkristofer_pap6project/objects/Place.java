// Kristofer Mann
// PAP6 - 1802
// Place.java
package com.example.klae.mannkristofer_pap6project.objects;


import java.io.Serializable;

public class Place implements Serializable {

    private final String lat;
    private final String lng;
    private final String name;
    private final String id;
    private Details details;
    private boolean favorite;
    private String rating;

    public Place(String lat, String lng, String name, String id, @SuppressWarnings("SameParameterValue") boolean favorite) {
        this.lat = lat;
        this.lng = lng;
        this.name = name;
        this.id = id;
        this.favorite = favorite;
    }

    public String getLat() {
        return lat;
    }

    public String getLng() {
        return lng;
    }

    public String getName(){
        return name;
    }

    public String getId() {
        return id;
    }

    public Details getDetails() {
        return details;
    }

    public boolean isFavorite() {
        return favorite;
    }

    public void setFavorite(boolean favorite) {
        this.favorite = favorite;
    }

    public void setDetails(Details details) {
        this.details = details;
    }

    @Override
    public String toString() {
        return "Place{" +
                "lat='" + lat + '\'' +
                ", lng='" + lng + '\'' +
                ", name='" + name + '\'' +
                ", id='" + id + '\'' +
                '}';
    }

    public String getRating() {
        return rating;
    }

    public void setRating(String rating) {
        this.rating = rating;
    }
}
