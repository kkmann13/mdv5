// Kristofer Mann
// PAP6 - 1802
// NetworkUtilities.java
package com.example.klae.mannkristofer_pap6project.network;


import android.content.Context;
import android.net.ConnectivityManager;
import android.net.NetworkInfo;

import org.apache.commons.io.IOUtils;

import java.io.IOException;
import java.io.InputStream;
import java.net.URL;

import javax.net.ssl.HttpsURLConnection;

public class NetworkUtilities {

    // This checks to see if the system is connected and returns a bool as a result
    public boolean isConnected(Context context){
        ConnectivityManager connectivityManager = (ConnectivityManager)context.getSystemService(Context.CONNECTIVITY_SERVICE);
        if(connectivityManager != null){
            NetworkInfo networkInfo = connectivityManager.getActiveNetworkInfo();
            if(networkInfo != null){
                if(networkInfo.isConnected()){
                    return true;
                }
            }
        }
        return false;
    }

    // This retrieves the JSON string data from the url
    static String getDataString(String urlString){
        try{
            URL url = new URL(urlString);
            HttpsURLConnection connection = (HttpsURLConnection)url.openConnection();
            connection.connect();
            InputStream inputStream = connection.getInputStream();
            String dataString = IOUtils.toString(inputStream, "UTF-8");
            inputStream.close();
            connection.disconnect();
            return dataString;
        } catch (IOException e) {
            e.printStackTrace();
        }
        return null;
    }
}
