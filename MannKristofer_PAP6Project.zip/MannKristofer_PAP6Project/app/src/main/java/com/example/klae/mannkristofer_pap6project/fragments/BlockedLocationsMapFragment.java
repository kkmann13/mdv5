// Kristofer Mann
// PAP6 - 1802
// BlockedLocationsMapFragment.java
package com.example.klae.mannkristofer_pap6project.fragments;

import android.app.AlertDialog;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.graphics.Color;
import android.net.Uri;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.widget.Button;
import android.widget.ImageButton;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import com.example.klae.mannkristofer_pap6project.R;
import com.example.klae.mannkristofer_pap6project.objects.Details;
import com.example.klae.mannkristofer_pap6project.objects.Place;
import com.google.android.gms.maps.CameraUpdate;
import com.google.android.gms.maps.CameraUpdateFactory;
import com.google.android.gms.maps.GoogleMap;
import com.google.android.gms.maps.MapFragment;
import com.google.android.gms.maps.OnMapReadyCallback;
import com.google.android.gms.maps.model.LatLng;
import com.google.android.gms.maps.model.Marker;
import com.google.android.gms.maps.model.MarkerOptions;
import com.squareup.picasso.Picasso;

import java.util.ArrayList;
import java.util.Objects;


public class BlockedLocationsMapFragment extends MapFragment implements OnMapReadyCallback, GoogleMap.InfoWindowAdapter, GoogleMap.OnInfoWindowClickListener {

    private static final String ARGS_DISCARDED_PLACES = "ARGS_DISCARDED_PLACES";
    private static final String ARGS_FAVORITE_PLACES = "ARGS_FAVORITE_PLACES";
    private static final String ARGS_LOCATION = "ARGS_LOCATION";
    private BlockedLocationsListener mListener;

    // Interface to communicate with the Activity
    // This was before the dataHandler was created
    public interface BlockedLocationsListener{
        void savePlaces(ArrayList<Place> places, String type);
    }

    // This receives a LatLng, arrayList of discarded places, and an arrayList of favorite places
    // It puts them into the args so that they can be retrieved later in the fragment
    public static BlockedLocationsMapFragment newInstance(LatLng latLng,ArrayList<Place> discarded, ArrayList<Place> favorite) {

        Bundle args = new Bundle();
        args.putParcelable(ARGS_LOCATION,latLng);
        args.putSerializable(ARGS_DISCARDED_PLACES,discarded);
        args.putSerializable(ARGS_FAVORITE_PLACES,favorite);

        BlockedLocationsMapFragment fragment = new BlockedLocationsMapFragment();
        fragment.setArguments(args);
        return fragment;
    }

    // Makes sure the Activity implements the interface
    @Override
    public void onAttach(Context context) {
        super.onAttach(context);
        if(getContext() instanceof BlockedLocationsListener ){
            mListener = (BlockedLocationsListener) getContext();
        }
    }

    @Override
    public void onActivityCreated(Bundle bundle) {
        super.onActivityCreated(bundle);
        getMapAsync(this);

    }

    // Provides the data to the map, sets the info window adapter, and the info window click listener
    @Override
    public void onMapReady(GoogleMap googleMap) {
        googleMap.setInfoWindowAdapter(this);
        googleMap.setOnInfoWindowClickListener(this);

        // This retrieves the discarded places arrayList from the args
        // Then it loops through the list to add a new map marker based upon the place's saved LatLng
        // It also sets the tag of the marker to that of the place to be referenced
        if(getArguments() != null){
            LatLng latLng = getArguments().getParcelable(ARGS_LOCATION);
            @SuppressWarnings("unchecked") ArrayList<Place> places = (ArrayList<Place>)getArguments().getSerializable(ARGS_DISCARDED_PLACES);
            if(places != null){
                for(int i=0;i<places.size();i++){
                    Place place = places.get(i);
                    LatLng loc = new LatLng(Double.parseDouble(place.getLat()),Double.parseDouble(place.getLng()));
                    googleMap.addMarker(new MarkerOptions().position(loc).title(place.getName())).setTag(place);
                }
            }

            // The camera is updated based upon the LatLng and moves the camera
            CameraUpdate cameraUpdate = CameraUpdateFactory.newLatLngZoom(latLng,12);
            googleMap.moveCamera(cameraUpdate);
        }
    }

    @Override
    public View getInfoWindow(Marker marker) {
        return null;
    }

    // Sets the contents of the info window to that of a custom view
    // This is to present a larger area for the user to tap the info window
    // The one provided was too small
    @Override
    public View getInfoContents(Marker marker) {
        View view = LayoutInflater.from(getContext()).inflate(R.layout.info_window,null);
        ((TextView)view.findViewById(R.id.name_textView)).setText(marker.getTitle());
        view.setBackgroundColor(Color.WHITE);
        return view;
    }

    // clickListener for the info window
    // It retrieves the discarded places from args and sets a place to that of the marker's tag
    @Override
    public void onInfoWindowClick(final Marker marker) {

        @SuppressWarnings("unchecked") final ArrayList<Place> discardedPlaces = (ArrayList<Place>) getArguments().getSerializable(ARGS_DISCARDED_PLACES);
        final Place place = (Place) marker.getTag();

        // This is the url and key to retrieve a photo from google
        String photoURL = "https://maps.googleapis.com/maps/api/place/photo?maxwidth=400&photoreference=";
        String key = "&key=AIzaSyC_NdBwpYCegNicZGxECXmJN1p9wL7vCwc";

        // An alert dialog is created and its view is set to the details view layout
        // This is to provide an easy access to details data and the handling of the that data
        // The user can easily visit a website, save, or discard a place from here
        // They can also quickly cancel the view to get directions from google maps
        final AlertDialog.Builder alertDialog = new AlertDialog.Builder(getContext());
        LayoutInflater layoutInflater = getActivity().getLayoutInflater();
        final View view = layoutInflater.inflate(R.layout.details_view,null);
        alertDialog.setView(view);
        alertDialog.setCancelable(true);

        // Sets the textView and its title
        TextView name = (TextView)view.findViewById(R.id.name_textView);
        name.setText(marker.getTitle());

        // Sets all of the UI elements by their associated id
        final ImageView photoImageView = (ImageView)view.findViewById(R.id.photo_imageView);
        final TextView addressTextView = (TextView)view.findViewById(R.id.address_textView);
        final TextView numberTextView = (TextView)view.findViewById(R.id.number_textView);
        final Button websiteButton = (Button)view.findViewById(R.id.website_button);
        final TextView ratingTextView = (TextView)view.findViewById(R.id.rating_textView);
        final TextView priceLebelTextView = (TextView)view.findViewById(R.id.priceLevel_textView);
        final TextView weekdayTextView = (TextView)view.findViewById(R.id.weekday_textView);
        final ImageButton addFavoriteButton = (ImageButton)view.findViewById(R.id.addFavorite_button);
        final ImageButton discardButton = (ImageButton)view.findViewById(R.id.discard_button);

        // This sets all of the UI based upon the discarded place's saved details
        // It also sets the website button's onClickListener to take the user to the website
        @SuppressWarnings("ConstantConditions") final Details details = place.getDetails();
        Picasso.with(getContext()).load(photoURL + details.getPhotoURL() + key).into(photoImageView);
        addressTextView.setText("Address: "+details.getAddress());
        numberTextView.setText("Number: "+details.getNumber());
        websiteButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(Intent.ACTION_VIEW, Uri.parse(details.getWebsite()));
                startActivity(intent);
            }
        });
        ratingTextView.setText("Rating: "+details.getRating());
        priceLebelTextView.setText("Price Level: "+details.getPriceLevel());
        weekdayTextView.setText(details.getHours());

        // This adds a discarded item to the favorites list and save it
        // It checks to see if favoritesPlaces is null just in case one has not been saved before in the app
        addFavoriteButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                @SuppressWarnings("unchecked") ArrayList<Place> favoritePlaces = (ArrayList<Place>)getArguments().getSerializable(ARGS_FAVORITE_PLACES);
                place.setFavorite(true);
                if(favoritePlaces == null){
                    //noinspection Convert2Diamond
                    favoritePlaces = new ArrayList<Place>();
                }

                // It adds the place to the list
                // Then it loops through th discarded list to get the index for removal
                favoritePlaces.add(place);
                int index = 100000;
                //noinspection ConstantConditions
                for(int i=0;i<discardedPlaces.size();i++){
                    if(Objects.equals(discardedPlaces.get(i).getId(), place.getId())){
                        index = i;
                    }
                }

                // If the index has changed, then the place is removed
                // The listener calls savePlaces twice to update the saved discarded and favorite places
                // The buttons are hidden to prevent further action
                if(index != 100000){
                    discardedPlaces.remove(index);
                    mListener.savePlaces(discardedPlaces,"discard");
                    mListener.savePlaces(favoritePlaces,"favorite");
                    marker.remove();
                    discardButton.setVisibility(View.GONE);
                    addFavoriteButton.setVisibility(View.GONE);
                    Toast.makeText(getContext(),"Saved",Toast.LENGTH_SHORT).show();
                }
            }
        });

        // This button removes the place from the discarded list
        // It loops through the discarded list and finds the index of the place to be removed
        discardButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                int index = 100000;
                //noinspection ConstantConditions
                for(int i=0;i<discardedPlaces.size();i++){
                    if(Objects.equals(discardedPlaces.get(i).getId(), place.getId())){
                        index = i;
                    }
                }

                // If the index changed, the place is removed from the list and map
                // It updates the discarded places list and removes the buttton to prevent further action
                if(index != 100000){
                    discardedPlaces.remove(index);
                    mListener.savePlaces(discardedPlaces,"discard");
                    marker.remove();
                    discardButton.setVisibility(View.GONE);
                    Toast.makeText(getContext(),"Removed from Blocked",Toast.LENGTH_SHORT).show();
                }
            }
        });

        alertDialog.setPositiveButton("Cancel", new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialog, int which) {
                dialog.cancel();
            }
        });

        alertDialog.show();
    }


}
