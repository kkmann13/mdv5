// Kristofer Mann
// PAP6 - 1802
// DataTask.java
package com.example.klae.mannkristofer_pap6project.network;

import android.os.AsyncTask;

import com.example.klae.mannkristofer_pap6project.MainActivity;
import com.example.klae.mannkristofer_pap6project.objects.Place;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.util.ArrayList;

// This is where we retrieve the data from the Google Places Web API
public class DataTask extends AsyncTask<Void,Void,ArrayList<Place>> {

    private final MainActivity mainActivity;
    private String mLocation = "";

    // It receives the MainActivity and the user's current location and sets them to the variables
    public DataTask(MainActivity activity, String location){
        mainActivity = activity;
        mLocation = location;
    }

    // This returns a list of places after the NetworkUtilities gets the string from the url
    // getPlaces is provided the string data and parses through it
    @Override
    protected ArrayList<Place> doInBackground(Void... params) {
        ArrayList<Place> places;
        String mURL = "https://maps.googleapis.com/maps/api/place/nearbysearch/json?type=restaurant&type=food&location=";
        String mRadius = "&radius=9000";
        String mPageToken = "&pagetoken";
        String mKey = "&key=AIzaSyC_NdBwpYCegNicZGxECXmJN1p9wL7vCwc";
        String data = NetworkUtilities
                .getDataString(mURL + mLocation + mRadius + mPageToken + mKey);
        places = getPlaces(data);
        return places;
    }

    // This returns an arrayList of places after it loops through all of the location in the JSON data
    // It retrieves all of the necessary strings to create a place object
    private ArrayList<Place> getPlaces(String data){
        ArrayList<Place> places = new ArrayList<>();
        try {
            JSONObject jsonObject = new JSONObject(data);
            JSONArray jsonArray = jsonObject.getJSONArray("results");
            for(int i=0;i<jsonArray.length();i++) {
                JSONObject object = jsonArray.getJSONObject(i);
                JSONObject geometry = object.getJSONObject("geometry");
                JSONObject location = geometry.getJSONObject("location");
                String lat = location.getString("lat");
                String lng = location.getString("lng");
                String name = object.getString("name");
                String id = object.getString("place_id");
                places.add(new Place(lat, lng, name, id, false));
            }
            return places;
        } catch (JSONException e) {
            e.printStackTrace();
        }
        return null;
    }

    // This sends the places to MainActivity to work with
    @Override
    protected void onPostExecute(ArrayList<Place> places) {
        super.onPostExecute(places);
        mainActivity.getChosenPlace(places);
    }
}
